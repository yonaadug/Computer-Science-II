package assignment2;

/**
 * 
 * @author Yonathan Kebede
 *
 */
public class QueueOverflowException extends RuntimeException{

	public QueueOverflowException() {
		// TODO Auto-generated constructor stub
	}
	
	public QueueOverflowException(String message) {
		super(message);
	}

}
