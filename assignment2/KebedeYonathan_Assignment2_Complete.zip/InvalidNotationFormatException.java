package assignment2;

/**
 * 
 * @author Yonathan Kebede
 *
 */
public class InvalidNotationFormatException extends RuntimeException {

	public InvalidNotationFormatException() {
		
	}
	
	public InvalidNotationFormatException(String message) {
		super(message);
	}

}
