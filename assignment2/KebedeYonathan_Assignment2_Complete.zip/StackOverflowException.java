package assignment2;

/**
 * 
 * @author Yonathan Kebede
 *
 */
public class StackOverflowException extends RuntimeException{

	public StackOverflowException() {
		// TODO Auto-generated constructor stub
	}
	
	public StackOverflowException(String message) {
		super(message);
	}

}
