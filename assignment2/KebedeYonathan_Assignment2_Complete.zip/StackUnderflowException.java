package assignment2;

/**
 * 
 * @author Yonathan Kebede
 *
 */
public class StackUnderflowException extends RuntimeException{

	public StackUnderflowException() {
		// TODO Auto-generated constructor stub
	}
	
	public StackUnderflowException(String message) {
		super(message);
	}

}
