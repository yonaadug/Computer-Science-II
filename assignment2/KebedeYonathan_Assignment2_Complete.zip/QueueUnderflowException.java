package assignment2;

/**
 * 
 * @author Yonathan Kebede
 *
 */
public class QueueUnderflowException extends RuntimeException{

	public QueueUnderflowException() {
		// TODO Auto-generated constructor stub
	}
	
	public QueueUnderflowException(String message) {
		// TODO Auto-generated constructor stub
		super(message);		
	}

}
